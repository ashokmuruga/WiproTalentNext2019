package com.wipro.candidate.service;
import com.wipro.candidate.dao.*;
import java.util.ArrayList;
import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.WrongDataException;






public class CandidateMain 
{

	/**
	 * @param args
	 */
	
	CandidateDAO d=new CandidateDAO();
	public String validate(CandidateBean studBean) throws WrongDataException
	{

	if(studBean==null)
	{
	throw new WrongDataException();

	}
	if(studBean.getName()==null || studBean.getName().length()<2)
	{
	throw new WrongDataException();

	}
	if((studBean.getM1()<0||studBean.getM1()>100)||(studBean.getM2()<0||studBean.getM2()>100)||(studBean.getM3()<0||studBean.getM3()>100))
	{
	throw new WrongDataException();

	}
	//System.out.println("end of validate");
	//System.out.println("validate");
	return "SUCCESS";

	}

	public String addCandidate(CandidateBean studBean)
	{
		
		String result="Data Incorrect";
		String  val="";
		try
		{
		val=validate(studBean);
		}
		catch(Exception e)
		{
		e.printStackTrace();

		}

		if(val.equals("SUCCESS"))
		{
		String id= d.generateCandidateId(studBean.getName());
		studBean.setId(id);

		int total=studBean.getM1()+studBean.getM2()+studBean.getM3();
		if(total>=240)
		{
		studBean.setResult("PASS");
		studBean.setGrade("Distinction");
		}

		if(total>=180&&total<240)
		{
		studBean.setResult("PASS");
		studBean.setGrade("First Class");
		}
		if(total>=150&&total<180)
		{
		studBean.setResult("PASS");
		studBean.setGrade("Second Class");
		}
		if(total>=105&&total<150)
		{
		studBean.setResult("PASS");
		studBean.setGrade("Third Class");
		}
		if(total<105)
		{
		studBean.setResult("FAIL");
		studBean.setGrade("No Grade");
		}

		result=d.addCandidate(studBean);

		val= result+":"+studBean.getResult();
			
	}
		return val;
	}
	public ArrayList<CandidateBean> displayAll(String criteria)
	{
		ArrayList<CandidateBean>	list = null;
		if(criteria.equals("PASS")||criteria.equals("FAIL")||criteria.equals("ALL"))
		{
		list=d.getByResult(criteria);

		} else
		try {
		throw new WrongDataException();
		} catch (WrongDataException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}


		return list;
		
		
		
	}
	public static void main(String[] args) {
		//write code here
		CandidateMain candidateMain = new CandidateMain();
		CandidateBean s2=new CandidateBean();
		s2.setName("RAJESH");
		s2.setM1(60);
		s2.setM1(90);

		s2.setM1(90);


		try
		{
		String result = candidateMain.addCandidate(s2);
		//candidateMain.displayAll("ALL");

		System.out.println(result);
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
	}

}
