package com.wipro.candidate.dao;


import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;
import java.sql.*;

public class CandidateDAO {
	public String addCandidate(CandidateBean studentBean)
	{
		String status="Error";
		try
		{

		Connection con1=DBUtil.getDBConn();
		//String id= generateCandidateId(studentBean.getName());
		PreparedStatement st=con1.prepareStatement
		("insert into CANDIDATE_TBL values(?,?,?,?,?,?,?)");

		st.setString(1, studentBean.getId());
		st.setString(2,studentBean.getName());
		st.setInt(3,studentBean.getM1());
		st.setInt(4,studentBean.getM2());	
		st.setInt(5,studentBean.getM3());
		st.setString(6,studentBean.getResult() );
		st.setString(7,studentBean.getGrade());
		status=studentBean.getId();
		int r=st.executeUpdate();


		if ( r == 1) return status;

		}catch(Exception ex)
		{
		 
		return "FAIL";
		}
		return status;
		 

	}

	public ArrayList<CandidateBean> getByResult(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		//write code here
		Connection con;
		PreparedStatement pst1;
		try
		{
		con=DBUtil.getDBConn();
		String sql="Select *from Candidate_TBL where Result=?";
		String sql1="Select *from Candidate_TBL";
		if(criteria.equals("ALL"))
		{
		pst1=con.prepareStatement(sql1);


		}
		else
		{
		pst1=con.prepareStatement(sql);
		pst1.setString(1, criteria);

		ResultSet rs=pst1.executeQuery();
		while(rs.next())
		{
		CandidateBean c=new CandidateBean();
		c.setId(rs.getString(1));
		c.setName(rs.getString(2));
		c.setM1(rs.getInt(3));
		c.setM2(rs.getInt(4));
		c.setM3(rs.getInt(5));
		c.setResult(rs.getString(6));
		c.setGrade(rs.getString(7));
		list.add(c);

		}

		}	
		}catch(Exception e)

		{
		return null;
		}
		return list;
	}
	public String generateCandidateId (String name)
	{
		String id="Data Incorrect";
		try
		{
		Connection con=DBUtil.getDBConn();

		PreparedStatement st=con.prepareStatement("select candid_seq.nextval from dual");

		ResultSet rs=st.executeQuery();
		rs.next();
		String two=name.substring(0,2).toUpperCase();
		id=two+rs.getInt(1);

		return  id;
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		return id;

	}
}
