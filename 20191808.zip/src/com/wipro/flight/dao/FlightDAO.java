package com.wipro.flight.dao;

import com.wipro.flight.bean.Flight;
import com.wipro.flight.util.DBUtil;

import java.sql.*;
import java.util.regex.Pattern;
public class FlightDAO  {
	Flight f=new Flight();
	public String addFlight(Flight flight) {
		if(flight!=null){
		try
		{

		Connection con1=DBUtil.getDBConnection();
		//String id= generateCandidateId(studentBean.getName());
		PreparedStatement st=con1.prepareStatement("insert into Flight_Tbl values(?,?,?,?,?,?,?,?)");

		st.setString(1, flight.getFlightID());
		st.setString(2, flight.getFlightName());
		st.setString(3, flight.getSource());
		st.setString(4,flight.getDestination());	
		st.setInt(5,flight.getEconomySeats());
		st.setInt(6, flight.getBusinessSeats());
		st.setInt(7,flight.getFirstClassSeats());
		st.setString(8,flight.getFlightType());
		int r=st.executeUpdate();


		if ( r  >=1) 
			return "SUCCESS";
		else 
			return "FAIL";

		}catch(Exception ex)
		{
		 System.out.println(ex.getMessage());
		//return "FAIL";
		}}
		return "FAIL";
	}

	
	public String getComputedId(String name, String seqName) {
		String result="";
	 
		String id = "";
		try
		{
		Connection con=DBUtil.getDBConnection();

		PreparedStatement st=con.prepareStatement("select FlightId_Seq.nextval from dual");
		if(name==null || seqName==null)
		{
			return "FAIL";
		}
		if(name.length()<2||!(Pattern.matches("[a-zA-Z]+", name)))
		{
			return "INVALID_INPUT";
		}
		if(seqName==null||seqName.length()<5)
		{
			return "INVALID_INPUT";
		}
		if(!(seqName.equalsIgnoreCase("FlightId_Seq")))
			{
				return "INVALID_INPUT";
			}
		String f1=name.substring(0,2).toUpperCase();
		ResultSet rs=st.executeQuery();
		rs.next();
	 
		id=f1+rs.getInt(1);
		f.setFlightID(id);

		return  id;
		}
		catch(Exception e)
		{
		e.printStackTrace();
		System.out.println(e.getMessage());
		}
		return "FAIL";
		//return result;
	}
}

/*
 * 	try
	{

	Connection con1=DBUtil.getDBConn();
	//String id= generateCandidateId(studentBean.getName());
	PreparedStatement st=con1.prepareStatement
	("insert into CANDIDATE_TBL values(?,?,?,?,?,?,?)");

	st.setString(1, studentBean.getId());
	st.setString(2,studentBean.getName());
	st.setInt(3,studentBean.getM1());
	st.setInt(4,studentBean.getM2());	
	st.setInt(5,studentBean.getM3());
	st.setString(6,studentBean.getResult() );
	st.setString(7,studentBean.getGrade());
	status=studentBean.getId();
	int r=st.executeUpdate();


	if ( r == 1) return status;

	}catch(Exception ex)
	{
	 
	return "FAIL";
	}
	return status;*/
