package com.wipro.candidate.dao;


import java.sql.*;
import java.util.*;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;
import com.wipro.candidate.util.WrongDataException;

public class CandidateDAO {
	//CandidateMain c=new CandidateMain();
	public String validate(CandidateBean studBean) throws WrongDataException
	{

	if(studBean==null)
	{
	throw new WrongDataException();

	}
	if(studBean.getName()==null || studBean.getName().length()<2)
	{
		throw new WrongDataException();

	}
	if((studBean.getM1()<0&&studBean.getM1()>100)||(studBean.getM2()<0&&studBean.getM2()>100)||(studBean.getM3()<0&&studBean.getM3()>100))
	{
	throw new WrongDataException();

	}
	//System.out.println("end of validate");
	//System.out.println("validate");
	return "SUCCESS";

	}
	
	public String addCandidate(CandidateBean studentBean)
	{
			String status="Data Incorrect";
			try {
				if(validate(studentBean).equals("SUCCESS")){
					status=generateCandidateId(studentBean.getName());
					
				}
				
				else
					return status;
			} catch (WrongDataException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try{
				Connection con = DBUtil.getDBConn();
				PreparedStatement ps = con.prepareStatement("insert into CANDIDATE_TBL values(?,?,?,?,?,?,?)");
				ps.setString(1, generateCandidateId(studentBean.getName()));
				ps.setString(2, studentBean.getName());
				ps.setInt(3, studentBean.getM1());
				ps.setInt(4, studentBean.getM2());
				ps.setInt(5, studentBean.getM3());
				ps.setString(6, studentBean.getResult());
				ps.setString(7, studentBean.getGrade());
				
				ps.executeUpdate();
				con.close();
//				status= status;
				
				}
				catch(Exception e){
					return "Data Incorrect";
				}
				
			return status;
	}
//	public ArrayList<CandidateBean> getByResult(String criteria)
//	{
//		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
//		//write code here
////		CandidateBean c;
//		Connection con;
//		try {
//			con = DBUtil.getDBConn();
//			PreparedStatement ps;
//			String sql = "select * from CANDIDATE_TBL";
//			if(criteria.equals("PASS") || criteria.equals("FAIL")){
//				sql=sql+" where Result = ?";
//				ps = con.prepareStatement(sql);
//				ps.setString(1, criteria);
//			}
//			else if(criteria.equals("ALL") ){
//				ps = con.prepareStatement(sql);
//			}
//			else
//				return null;
//			
//			ResultSet rs= ps.executeQuery();
//			while(rs.next()){
//				CandidateBean c= new CandidateBean();
//				c.setId(rs.getString(1));
//				c.setName(rs.getString(2));
//				c.setM1(rs.getInt(3));
//				c.setM2(rs.getInt(4));
//				c.setM3(rs.getInt(5));
//				c.setResult(rs.getString(6));
//				c.setGrade(rs.getString(7));
//				list.add(c);
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//			return null;
//		}
//		return list;
//	}
	public ArrayList<CandidateBean> getByResult(String criteria)
	{
	ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();

	Connection con;
	PreparedStatement pst1;
	try
	{
	con=DBUtil.getDBConn();
	String sql="Select *from Candidate_TBL where Result=?";
	String sql1="Select *from Candidate_TBL";
	if(criteria.equals("ALL"))
	{
	pst1=con.prepareStatement(sql1);

		String str=new StringBuffer("Vijay").reverse().toString();
	}
	else
	{
	pst1=con.prepareStatement(sql);
	pst1.setString(1, criteria);

	ResultSet rs=pst1.executeQuery();
	while(rs.next())
	{
	CandidateBean c=new CandidateBean();
	c.setId(rs.getString(1));
	c.setName(rs.getString(2));
	c.setM1(rs.getInt(3));
	c.setM2(rs.getInt(4));
	c.setM3(rs.getInt(5));
	c.setResult(rs.getString(6));
	c.setGrade(rs.getString(7));
	list.add(c);

	}

	}	
	}catch(Exception e)

	{
	return null;
	}
	return list;
	}
//	public String generateCandidateId (String name)
//	{
//		String id="Data Incorrect";
//		try {
//			Connection con = DBUtil.getDBConn();
////			System.out.println("Connection established");
//			
//			PreparedStatement ps = con.prepareStatement("select candid_seq.nextval from dual");
//			ResultSet rs =ps.executeQuery();
//			rs.next();
//			String two = name.substring(0,2).toUpperCase();
//			id = two+rs.getInt(1);
////			System.out.println(id.length()+"   ---   "+id);
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//			return id;
//		}
//		return id;
//		
//	}
	public String generateCandidateId (String name)
	{
	String id="Data Incorrect";
	try
	{
	Connection con=DBUtil.getDBConn();

	PreparedStatement st=con.prepareStatement("select candid_seq.nextval from dual");

	ResultSet rs=st.executeQuery();
	rs.next();
	String two=name.substring(0,2).toUpperCase();
	id=two+rs.getInt(1);

	return  id;
	}
	catch(Exception e)
	{
	e.printStackTrace();
	}
	return id;


	}
}
