package com.wipro.eb.exception;

public class InvalidReadingException extends Exception{

	@Override
	public String toString() {
		//write code here
		return "Incorrect Reading";
	}
	
	

}
