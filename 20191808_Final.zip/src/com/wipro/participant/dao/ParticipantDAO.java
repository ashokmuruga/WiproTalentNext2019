package com.wipro.participant.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;

import com.wipro.participant.bean.ParticipantBean;
import com.wipro.participant.util.DBUtil;

public class ParticipantDAO {
	
	
	public String generateId(String studentname)
	{
		String id="";
		Connection con=null;
		  try{
		   con=DBUtil.getDBConnection();
		   PreparedStatement ps=con.prepareStatement("select PARTICIPANTID_SEQ.nextval fron dual");
		   ResultSet rs= ps.executeQuery();
		   rs.next();
		   int len=studentname.length();
		   if(len>2)
		   {
		   String st=studentname.substring(0,3).toUpperCase();
		   //System.out.println(st);
		   id=st+rs.getInt(1);
		   }
		   else
			   return "INVALID";
		  }catch(Exception e){
		   e.printStackTrace();
		  }
				//Write your code here
		return id;
	}

	public String createParticipant(ParticipantBean bean)
	{
		String result="";
			//Write your code here
		Connection con=null;
		  try{
		   con=DBUtil.getDBConnection();
		   PreparedStatement ps=con.prepareStatement("insert into PARTICIPANT_TABLE values(?,?,?,?,?,?,?,?,?)");
		   ps.setString(1, bean.getId());
		   ps.setString(2, bean.getName());
		   ps.setInt(3, bean.getTheoryMark1());
		   ps.setInt(4, bean.getTheoryMark2());
		   ps.setInt(5, bean.getPracticalMark1());
		   ps.setInt(6, bean.getPracticalMark2());
		   ps.setString(7, bean.getSportsQuotaPresent());
		   ps.setInt(8, bean.getTotal());
		   ps.setString(9, bean.getResult());
		   int k=ps.executeUpdate();
		   if(k>0)
		    result="SUCCESS";
		   else
		    result="FAIL";
		  }
		  catch(Exception e){
		   result="FAIL";
		   e.printStackTrace();
		  }
		return result;
	}
	
	
}
