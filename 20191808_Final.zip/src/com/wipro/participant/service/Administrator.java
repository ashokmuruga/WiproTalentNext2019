package com.wipro.participant.service;

import com.wipro.participant.bean.ParticipantBean;
import com.wipro.participant.dao.ParticipantDAO;
import com.wipro.participant.util.InvalidInputException;

public class Administrator {
	
	
	public String addParticipant(ParticipantBean bean)
	{
		//Write your code here
		ParticipantDAO dao=new ParticipantDAO();
		  String result="";
		  String result1="";
		  String id="";
		   
		  if(bean==null)
		   result="Invalid Data in Input";  
		  else if(bean.getName()==null)
		   result="Invalid Data in Input";  
		  else if(bean.getName().length()<2)
		   result="Invalid Data in Input";  
		  else if(bean.getSportsQuotaPresent()!="Yes"&&bean.getSportsQuotaPresent()!="No")
		   result="Invalid Data in Input";
		  else if(bean.getTheoryMark1()<0)
		    result="THEORY MARK IS INVALID";
		  else if(bean.getTheoryMark1()>40)
		    result="THEORY MARK IS INVALID";
		  else if(bean.getTheoryMark2()<0)
		    result="THEORY MARK IS INVALID";
		  else if(bean.getTheoryMark2()>40)
		    result="THEORY MARK IS INVALID";
		  
		  else if(bean.getPracticalMark1()<0)
		   result="PRACTICAL MARK IS INVALID";
		  else if(bean.getPracticalMark1()>60)
		   result="PRACTICAL MARK IS INVALID";
		  else if(bean.getPracticalMark2()<0)
		   result="PRACTICAL MARK IS INVALID";
		  else if(bean.getPracticalMark2()>60)
		   result="PRACTICAL MARK IS INVALID";
		  else{
		   id=dao.generateId( bean.getName());
		   bean.setId(id);
		   int tottheory=(int)(bean.getTheoryMark1()+bean.getTheoryMark2())/2;
		   int totprac=(int)(bean.getPracticalMark1()+bean.getPracticalMark2())/2;
		   int tot=totprac+tottheory;
		   bean.setTotal(tot);
		   if(bean.getSportsQuotaPresent().equals("Yes")&&(tot>=70))
		    result1="PASS";
		   else if(bean.getSportsQuotaPresent().equals("No")&&(tot>=75))
		    result1="PASS";
		   else
		    result1="FAIL";
		   bean.setResult(result1);
		   dao.createParticipant(bean);
		   result=id+":"+result1;
		  }
		return result;		
				
	}
	
	
	public static void main(String[] args) {
		
		//Write your code here
		ParticipantBean bean=new ParticipantBean();

		bean.setName("ABC");

		bean.setPracticalMark1(40);

		bean.setPracticalMark2(40);

		bean.setTheoryMark1(30);

		bean.setTheoryMark2(30);

		bean.setSportsQuotaPresent("Yes");

		Administrator admin= new Administrator();

		System.out.println(admin.addParticipant(bean));
		

	}

}
